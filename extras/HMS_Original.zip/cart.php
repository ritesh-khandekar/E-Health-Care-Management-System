<?php
session_start();
if(!isset($_SESSION["hms_login"])){
    header("location: ./");
}
   if($_SESSION["hms_doctor"]){
      echo $_SESSION["hms_doctor"];
      header("location: doctorhome.php?".$_SERVER['QUERY_STRING']);
      return;
   }
   if($_SESSION["hms_admin"]){
      header("location: adminhome.php?".$_SERVER['QUERY_STRING']);
      return;
   }
   require("methods.php");
   $login = false;
   if(islogin()){
      global $login;
      $login = true;
   }
   if(!isset($_SESSION["hms_medicines"])){ 
    header("location: pharmacy.php"); 
    return;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart HOSPITAL MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body class="pt-4">
    <nav class="navbar navbar-expand-lg p-3 fixed-top navbar-light bg-white shadow-sm" >
        <a class="navbar-brand h5" href="#">HOSPITAL MANAGEMENT SYSTEM</b>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav ml-auto mr-0 mt-2 mt-lg-0">
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="home.php">HOME</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="about.php">ABOUT</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="alldoctors.php">ALL_DOCTORS</a></li>
            <?php
               if($login):
               ?>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="dashboard.php">DASHBOARD</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="logout.php">LOGOUT</a></li>
            <?php else: ?>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="register.php">REGISTER</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="login.php">LOGIN</a></li>
            <?php endif ?>
          </ul>
          
        </div>
      </nav>
      <br>
    <main class="container p-2">
      <div class="d-none">
        <div class="h3 text-primary m-4">Selected Medicines:</div>
        <table class="table table-bordered table-striped" id="updatetable">
          <thead>
            <tr>
              <th>Medicine Name</th>
              <th>Description</th>
              <th>Remaining</th>
              <th>Price</th>
              <th>Medicine ID</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>

          </tbody>
        </table>
      </div>
        <div class="h3 text-primary m-4">Selected Medicines:</div>
 
  <table class="table table-bordered" id="updatetable">
    <thead>
      <tr>
        <th>Medicine Name</th>
        <th>Description</th>
        <th>Price</th>

        <th>Medicine ID</th>
        <th>Quantity</th>
      </tr>
    </thead>
    <tbody>
        <?php
        require("conn.php");
        $price = 0;
        $meds = $_SESSION["hms_medicines"];
        foreach($meds as $o){
        $id = $o["dataid"];
        $quan = $o["quantity"];
        $q = "SELECT*FROM pharmacy WHERE medicineid='$id'";
        $q = $con->query($q);
        if(0==mysqli_num_rows($q)){
          header("location:cart.php");
          return;
        }
        while($row=mysqli_fetch_array($q)){
                echo "<tr>";
                echo "<td>".$row["name"]."</td>";
                echo "<td>".$row["description"]."</td>";
                echo "<td>".$row["price"]."</td>";
                echo "<td data-id='".$row["medicineid"]."'>".substr($row["medicineid"],0,20)."...</td>";
                echo "<td>";
                echo $quan;
                echo "</td>";
                echo "</tr>";
                $price += (int)$row["price"] *((int) $quan);
                
            }
        }
            ?>
            <?php
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
require("config.php");
$api = new Api($keyId, $keySecret);
$orderData = [
    'receipt'         => 'rcptid_11',
    'amount'          => $price*100, // 39900 rupees in paise
    'currency'        => 'INR'
];

$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder["id"];

$_SESSION["razorpay_order_id"] = $razorpayOrderId;
$displayAmount = $amount = $orderData["amount"];
$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => "Hospital Management System",
    "description"       => "Buy Medicines",
    //"image"             => "",
    "prefill"           => [
    "name"              => $_SESSION["hms_login_fname"]." ".$_SESSION["hms_login_lname"],
    "email"             => $_SESSION["hms_login_email"],
    //"contact"           => ,
    ],
    "notes"             => [
    //"address"           => "",
    //"merchant_order_id" => "",
    ],
    "theme"             => [
        
    ],
    "order_id"          => $razorpayOrderId,
];
$json = json_encode($data);
if(!isset($_SESSION["hms_medicines"])) return;
$uid = (int) $_SESSION["hms_user_id"];
$strmedicines =json_encode($_SESSION["hms_medicines"]);
$time = (int) time();
$price = (int) $price;
$paymentid = getRandomHex(40);
$q = "INSERT INTO medicines VALUES(0,$time,$uid,'$strmedicines',$price,'$paymentid','','$razorpayOrderId','')";
//echo $q;
if(!$con->query($q)){
    return;
}
function getRandomHex($num_bytes=4) {
    return bin2hex(openssl_random_pseudo_bytes($num_bytes));
  }
?>
    </tbody>
  </table>
  <form name='razorpayform' action="verify.php" method="POST">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_signature"  id="razorpay_signature" >
</form>
  <div class = "w-100 text-center">
    <button class= "btn btn-outline-success p-2" id="buybtn">Buy Medicines Now <br><b>Total: ₹<?= $price?></b></button>
    <br>
    <button class= "btn btn-warning p-2 m-4" onclick="window.history.back()">Go Back</button>

  </div>
    </main>
    <footer class="container">
        <p class="float-right"><a href="#">Back to top</a></p>
        <p>© 2017-2018 Company, Inc. · <a href="#">Privacy</a> · <a href="#">Terms</a></p>
      </footer>
      <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
// Checkout details as a json
var options = <?php echo $json?>;

/**
* The entire list of checkout fields is available at
* https://docs.razorpay.com/docs/checkout-form#checkout-fields
*/
options.handler = function (response){
    document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
    document.getElementById('razorpay_signature').value = response.razorpay_signature;
    document.razorpayform.submit();
};

// Boolean whether to show image inside a white frame. (default: true)
options.theme.image_padding = false;

var rzp = new Razorpay(options);

document.getElementById('buybtn').onclick = function(e){
    rzp.open();
    e.preventDefault();
}
</script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body>
</html>

