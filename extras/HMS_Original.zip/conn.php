<?php
$con= mysqli_connect("localhost","id18012491_root","m8FJ7di{-j*HQqjG","id18012491_hms_db") or die("Connection Failed");
?>
