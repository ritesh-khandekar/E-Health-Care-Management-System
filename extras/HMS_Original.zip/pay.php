<?php
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
require("config.php");
session_start();
$api = new Api($keyId, $keySecret);
$orderData = [
    'receipt'         => 'rcptid_11',
    'amount'          => 4900, // 39900 rupees in paise
    'currency'        => 'INR'
];

$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder["id"];
$_SESSION["razorpay_order_id"] = $razorpayOrderId;
$displayAmount = $amount = $orderData["amount"];
$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => "Acme Corp",
    "description"       => "Buy best price",
    "image"             => "https://cdn.razorpay.com/logos/FFATTsJeURNMxx_medium.png",
    "prefill"           => [
    "name"              => "Gaurav Kumar",
    "email"             => "gaurav.kumar@example.com",
    "contact"           => "9999999999",
    ],
    "notes"             => [
    "address"           => "Hello World",
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    ],
    "order_id"          => $razorpayOrderId,
];
$json = json_encode($data);
require("manual.php")
?>