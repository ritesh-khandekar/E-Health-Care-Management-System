<?php
require("config.php");
require("conn.php");
require('razorpay-php/Razorpay.php');
session_start();
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    $oid = $_SESSION['razorpay_order_id'];
    $pid= $_POST['razorpay_payment_id'];
    $s = $_POST['razorpay_signature'];
    $q = "UPDATE medicines SET `rp_payment_id`='$pid',`rp_signature`='$s' WHERE `rp_order_id`='$oid'";
    if($con->query($q)){
            $_SESSION["medicines_redirect"] = json_encode(array("success"=> true,"rp_paymentid"=>$pid,"rp_order_id"=>$oid,"rp_signature"=>$s));
            header("location: buymedicine.php");
    }

}
else
{
    $html =  json_encode(array("success"=> false));
    echo "<script>window.history.back()</script>";
}

echo $html;

?>