<?php
require("methods.php");
if(!isset($_SESSION["hms_medicines"])){header("location: pharmacy.php");}
$next = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"]:'';
$next = isset($_GET['next'])?$_GET['next']:'';
$login = false;
if(islogin()){
   global $login;
   $login = true;
}
if(!isset($_SESSION["hms_medicines"])) return;
$uid = (int) $_SESSION["hms_user_id"];
require("conn.php");
if(!isset( $_SESSION["medicines_redirect"])) return;
$data =json_decode($_SESSION["medicines_redirect"],true);
$rp_pid = $data["rp_paymentid"];
$rp_oid = $data["rp_order_id"];
$rp_s = $data["rp_signature"];
$q = "SELECT * FROM medicines WHERE `rp_payment_id`='$rp_pid' AND `rp_order_id`='$rp_oid' AND `rp_signature`='$rp_s'";
$r = $con->query($q);
if(mysqli_num_rows($r)!=1) return;
if($r){
    $row = mysqli_fetch_array($r);
    $real_pid = $row["paymentid"];
    
}else{
    return;
}
$strmedicines =json_encode($_SESSION["hms_medicines"]);//mysqli_real_escape_string($con,json_encode($_SESSION["hms_medicines"]));
$time = (int) time();

$paymentid = getRandomHex(40);
foreach($_SESSION["hms_medicines"] as $med){
    $id = $med['dataid'];
    $q = "SELECT * FROM pharmacy WHERE medicineid = '$id'";
    $q = $con->query($q);
    $info = mysqli_fetch_array($q)[4];
    $unit = (int) $info;
    $unit = $unit - $med["quantity"];
    $q = "UPDATE pharmacy SET unit=$unit WHERE medicineid='$id'";
    $con->query($q);
}
//mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
// $q = "INSERT INTO medicines VALUES(0,$time,$uid,'$strmedicines',$price,'$paymentid')";
// if($con->query($q)){
//     echo '{"success":"true","paymentid":"'.$paymentid.'"}';
// }else{
//     echo '{"success":"false"}';
// }
unset($_SESSION["medicines_redirect"]);
unset($_SESSION["hms_medicines"]);
unset($_SESSION["hms_medicines_price"]);
header("location: receipt.php?paymentid=".$real_pid);
function getRandomHex($num_bytes=4) {
    return bin2hex(openssl_random_pseudo_bytes($num_bytes));
  }
?>
