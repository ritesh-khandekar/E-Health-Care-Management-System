<?php
header("location: patienthome.php");
?>