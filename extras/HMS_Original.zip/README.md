E-HEALTH CARE MANAGEMENT SYSTEM
        <p>
            This project deals with the Healthcare Management. This project is very helpful to both Medicare staff as well as to the public. All the branches of the Medicare can be integrated with one to another. So any body can get the status of each branch easily from the Medicare center.
        </p>
        <p>
            People can take appointments online by approaching the website. That site also includes Information about the Facilities, Specialties available in every Medicare Branch. So they can also send their problems about their health and get some useful tips from the doctors.
        </p>
        <b>httpd-xampp.conf:</b>
```
<FilesMatch "\.html$">
    SetHandler application/x-httpd-php
</FilesMatch>
```
