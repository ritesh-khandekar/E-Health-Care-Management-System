<?php
$keyId = "rzp_test_MjAJQXcFxKACbr";
$keySecret = "x7C4uQBbdYwHYde5b56wqu3M";
$currency = "INR";