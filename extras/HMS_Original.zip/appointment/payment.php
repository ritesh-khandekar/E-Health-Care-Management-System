<?php
session_start();
$login = false;
if(isset($_SESSION["hms_login"])){
  if($_SESSION["hms_admin"] || $_SESSION["hms_doctor"]){
    header("location: ../");
  }
  if(!isset($_SESSION["hms_admin"]) || !isset($_SESSION["hms_doctor"])){
    header("location: ../alldoctors.php");
  }
   global $login;
   $login = true;
}else{
  header("location: ../");
}
require("../conn.php");
foreach($_POST as $key => $val){
  if($val=="") header("location: ".isset($_SERVER["HTTP_REFERER"])? $_SERVER["HTTP_REFERER"]: "../");
}
$docid = secure($_POST['doc-id']);
$spec = secure($_POST['spec']);
$fullname = secure($_POST['fullname']);
$phone = secure($_POST['phone']);
$email = secure($_POST['email']);
$date = secure($_POST['date']);
$time = secure($_POST['time']);
$area = secure($_POST['area']);
$city = secure($_POST['city']);
$state = secure($_POST['state']);
$postalcode = secure($_POST['postalcode']);
$q = "SELECT * FROM doctors WHERE `doc-id`='$docid' AND `spec`='$spec'";
$doc = $con->query($q);
if(mysqli_num_rows($doc)<1){
  header("location: ../alldoctors.php");
  return;
}
$doctor=1;
while($row=mysqli_fetch_array($doc)){
$doctor = $row;
}
$sessionemail = secure($_SESSION["hms_login_email"]);
$sessionfname = secure($_SESSION["hms_login_fname"]);
$sessionlname = secure($_SESSION["hms_login_lname"]);

$q = "SELECT id FROM users WHERE `fname`='$sessionfname' AND `lname`='$sessionlname' AND `email`='$sessionemail'";
$user = $con->query($q);
if(mysqli_num_rows($user)<1){
  header("location: ../alldoctors.php");
  return;
}
$hms_user=1;
while($row=mysqli_fetch_array($user)){
$hms_user = $row;
}
$_SESSION["hms_user_id"] = $hms_user["id"];

function secure($str){
  global $con;
  $str = mysqli_real_escape_string($con,$str);
  return $str;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment of Appointment HOSPITAL MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
          
  <style>
    .loader {
      margin-top: 20%;
      display: inline-block;
      border: 5px solid #dbdbdb;
      border-radius: 50%;
      clear: both;
      border-top: 5px solid #000000;
      width: 60px;
      height: 60px;
      -webkit-animation: spin 2s linear infinite; /* Safari */
      animation: spin 2s linear infinite;
    }
    
    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    </style>
</head>
<body class="pt-4">
    <nav class="navbar navbar-expand-lg p-3 fixed-top navbar-light bg-white shadow-sm" >
        <a class="navbar-brand h5" href="#">HOSPITAL MANAGEMENT SYSTEM</b>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav ml-auto mr-0 mt-2 mt-lg-0">
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../home.php">HOME</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../about.php">ABOUT</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../alldoctors.php">ALL_DOCTORS</a></li>
            <?php
               if($login):
               ?>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../dashboard.php">DASHBOARD</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../logout.php">LOGOUT</a></li>
            <?php else: ?>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../register.php">REGISTER</a></li>
            <li class="nav-item"><a class="nav-link m-1" style="color: #000;text-decoration:none" href="../login.php">LOGIN</a></li>
            <?php endif ?>
          </ul>
          
        </div>
      </nav>
      <br>
      <div id="cover" style="display:none;text-align:center;width:100%;height:100%;position:fixed;top:0;left:0;background:rgba(63, 63, 63, 0.6)">
        <div class="loader"></div>
        </div>
    <main class="container p-2 pt-4 mt-4">
        <form method="POST" id="formpayment" action="donepayment.php">
            <?php
            foreach($_POST as $key => $val){
              echo '<input type="hidden" name="'.secure($key).'" value="'.secure($val).'"/>';
            }
              ?>
          </form>
                      <?php
require('../razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
require("../config.php");
$api = new Api($keyId, $keySecret);
$orderData = [
    'receipt'         => getRandomHex(10),
    'amount'          => ((int)$doctor["fees"])*100, // 39900 rupees in paise
    'currency'        => 'INR'
];

$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder["id"];

$_SESSION["razorpay_order_id"] = $razorpayOrderId;
$displayAmount = $amount = $orderData["amount"];
$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => "Hospital Management System",
    "description"       => "Book Appointment",
    //"image"             => "",
    "prefill"           => [
    "name"              => $_SESSION["hms_login_fname"]." ".$_SESSION["hms_login_lname"],
    "email"             => $_SESSION["hms_login_email"],
    //"contact"           => ,
    ],
    "notes"             => [
    //"address"           => "",
    //"merchant_order_id" => "",
    ],
    "theme"             => [
        
    ],
    "order_id"          => $razorpayOrderId,
];
$json = json_encode($data);
$uid = (int) $_SESSION["hms_user_id"];
$time = (int) time();
$price = (int) $doctor["fees"];
$paymentid = getRandomHex(20);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$q = "INSERT INTO appointments VALUES(0,'$docid',$uid,'$date','$time','$area','$city','$state','$postalcode','$paymentid','','$price','false','$razorpayOrderId','','')";
//echo $q;
if(isset($_SESSION["pay_app_id"])){
    if($_SESSION["pay_app_id"]>time()+(1000*60*1)){
        if(!$con->query($q)){
            return;
        }
    }else{
        unset($_SESSION["pay_app_id"]);
    }

}else{
     if(!$con->query($q)){
            return;
        }
}
$_SESSION["pay_app_id"]= time();
function getRandomHex($num_bytes=4) {
    return bin2hex(openssl_random_pseudo_bytes($num_bytes));
  }
?>
  <form name='razorpayform' action="verify.php" method="POST">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_signature"  id="razorpay_signature" >
</form>
          <h3 class="text-primary my-3 py-3">Book Appointment</h3>
          <pre style="line-height: 0.4em;overflow: visible;">
<P>Name: <b><?= $fullname ?></b></p>
<p>Address: <b><?= $area ?>, <?= $city ?> - <?= $postalcode ?>, <?= $state ?></b></p>
<p>Appointment Date: <b><?= $date ?></b></p>
<p>Time: <b><?= $time ?></b></p>
<p>Doctor: <b><?='Dr. '.$doctor['name']?> <?=$doctor['lname']?></b> </p>
<p class="total">Total: <b style="font-size: medium;"><?='₹'.$doctor["fees"]?></b></p>
          </pre>
          <button class = "btn btn-outline-success p-2 mb-4" id="buybtn">Pay <?='₹'.$doctor["fees"]?></button>
    </main>
    <footer class="container">
        <p class="float-right"><a href="#">Back to top</a></p>
        <p>© 2017-2018 Company, Inc. · <a href="#">Privacy</a> · <a href="#">Terms</a></p>
      </footer>
       <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
      <script>
// Checkout details as a json
var options = <?php echo $json?>;

/**
* The entire list of checkout fields is available at
* https://docs.razorpay.com/docs/checkout-form#checkout-fields
*/
options.handler = function (response){
    document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
    document.getElementById('razorpay_signature').value = response.razorpay_signature;
    document.razorpayform.submit();
};

// Boolean whether to show image inside a white frame. (default: true)
options.theme.image_padding = false;

var rzp = new Razorpay(options);

document.getElementById('buybtn').onclick = function(e){
    rzp.open();
    e.preventDefault();
}
</script>
            <script>
                // function gateway(){
                //   setTimeout(() => {
                //     document.querySelector(".payment").style.display="none";
                //     document.querySelector(".paid").style.display="block";
                //   }, 4000);
                //   setTimeout(() => {
                //     document.querySelector("#cover").style.display="block";
                //   }, 5000);
                //   setTimeout(() => {
                //     document.querySelector("#formpayment").submit();
                //   }, 6000);
                //   window.open('gateway.php','_blank');
                // }
              </script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body>
</html>